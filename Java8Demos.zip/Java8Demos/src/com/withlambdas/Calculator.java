package com.withlambdas;

public interface Calculator 

{
int sum(int x,int y);
}
