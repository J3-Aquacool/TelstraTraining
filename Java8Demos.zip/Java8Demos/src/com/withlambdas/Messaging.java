package com.withlambdas;

public interface Messaging
{

void sendMessage(String mesg);


}



//