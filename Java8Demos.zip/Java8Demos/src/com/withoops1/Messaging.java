package com.withoops1;

public interface Messaging
{

void sendMessage();


}
