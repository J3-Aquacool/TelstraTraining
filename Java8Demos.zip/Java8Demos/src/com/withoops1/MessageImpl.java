package com.withoops1;

public class MessageImpl implements Messaging

{

	@Override
	public void sendMessage() {
		// TODO Auto-generated method stub
		
		System.out.println("Welcome to the Communications Department");
		
	}

}
