package com.withoops1;

public class MessagaApp 

{


public void show(Messaging m)
{
	
	m.sendMessage();
}


}
