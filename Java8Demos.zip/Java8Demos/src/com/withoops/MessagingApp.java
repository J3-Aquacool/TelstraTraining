package com.withoops;

public class MessagingApp {

	public void showMessage()
	{
		
		System.out.println("Welcome All");
	}
	
	public static void main(String[] args)
	
	{
		MessagingApp m=new MessagingApp();
		m.showMessage();

	}

}
