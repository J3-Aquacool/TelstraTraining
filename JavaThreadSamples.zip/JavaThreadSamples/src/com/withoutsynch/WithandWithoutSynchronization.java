package com.withoutsynch;

class Balance
{
 int balance=0;
	synchronized  void setBalance()
	{
		for(int i=0;i<5;i++)
		{
		
		balance=balance+1;
	   System.out.println(Thread.currentThread().getName()+"  Balance is:"+balance);
		try
		{
			
			Thread.sleep(1000);
		}catch(InterruptedException ie)
		{
			
			System.out.println("Who is Interruption :"+ie.getMessage());
		}
		}
	
		
		
	}// close the method
	
	
/*void setBalance()
	{
		
		synchronized(this)
		{
		for(int i=0;i<5;i++)
		{
		
		balance=balance+1;
	   System.out.println(Thread.currentThread().getName()+"  Balance is:"+balance);
		try
		{
			
			Thread.sleep(1000);
		}catch(InterruptedException ie)
		{
			
			System.out.println("Who is Interruption :"+ie.getMessage());
		}
		}
	
		
		}
	}// method closed
	*/
	
	
	
	
	
	
}

class Customer1 extends Thread
{
	
	Balance bal;
	Customer1(Balance bal)
	{
		this.bal=bal;
		
	}
	public void run()
	{
		
		bal.setBalance();
	}
	
	
}

class Customer2 extends Thread
{

	Balance bal;
	Customer2(Balance bal)
	{
		this.bal=bal;
		
	}
	
	public void run()
	{
		
		bal.setBalance();
	}
	
}
public class WithandWithoutSynchronization {

	public static void main(String[] args) {
		
		
		
		Balance  obj=new Balance();
		
		Customer1 c1=new Customer1(obj);
		c1.setName("Customer -1");
		
		
		Customer2 c2=new Customer2(obj);
		c2.setName("Customer -2");
		
		
		
		c1.start();
		c2.start();
		
		
	}

}
