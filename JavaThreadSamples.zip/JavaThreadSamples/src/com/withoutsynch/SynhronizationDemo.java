package com.withoutsynch;



class TokenGenerator
{
	
synchronized static void createTokenNumber(int a)
{
	
	for(int i=1;i<=a;i++)
	{
		
		System.out.println(Thread.currentThread().getName()+"Ur Token Number is:"+i);
	
	try
	{
		Thread.sleep(1000);
		
	}catch(InterruptedException ie)
	{
		
		System.out.println(" Problem :"+ie.getMessage());
	}
	}
}
	
	
}

class User extends Thread
{
	
	public void run()
	{
		
		TokenGenerator.createTokenNumber(5);
	}
}



class User1 extends Thread
{
	
	public void run()
	{
		
		TokenGenerator.createTokenNumber(10);
	}
}






public class SynhronizationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		User u=new User();
		User1 u1=new User1();
		
		u.setName("User Thread:");

		u1.setName("User1 Thread:");
		u1.setPriority(7);
		u.setPriority(3);
		
		u.start();
		u1.start();
		
		
		

	}

}
