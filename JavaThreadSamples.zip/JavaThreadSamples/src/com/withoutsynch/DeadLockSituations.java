package com.withoutsynch;
class ReaderTask
{
	
	public String readData()
	{
		
		return "Reading some files";
	}
	
}


class WriterTask
{
	public String writeData()
	{
		
		return "Writing some files";
	}
	
	
}


class ReadAndWrite implements Runnable
{
	ReaderTask r;
	WriterTask w;
	ReadAndWrite(ReaderTask r,WriterTask w)
	{
		this.r=r;
		this.w=w;
		
		
	}
	
	public void run()
	{
		
		synchronized(r)
		{
			
			
			try
			{
				Thread.sleep(3000);
			}catch(InterruptedException ie)
			{
				System.out.println("Interrpted Reader");
			}
		
		}
		synchronized (w) 
		{
			
		
		System.out.println("Inside Writer Functioality");
		}
		
		}
		
	
	
	
}
public class DeadLockSituations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ReadAndWrite rw=new ReadAndWrite(new ReaderTask(), new WriterTask());
		
		Thread t=new Thread(rw);
		Thread t1=new Thread(rw);
		t.start();
		t1.start();
		
	}

}
