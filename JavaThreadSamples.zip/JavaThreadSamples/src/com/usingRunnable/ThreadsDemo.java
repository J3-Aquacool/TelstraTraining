package com.usingRunnable;

class JobRead implements Runnable
{

	@Override
	public void run()
	{
		
		
		for(int i=0;i<10;i++)
		{
			System.out.println(Thread.currentThread().getName() +" Value is:"+i);
		
		}
		
		
	}
	
	
	
	
	
}







public class ThreadsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		JobRead j=new JobRead();
		
		Thread worker1=new Thread(j);
		worker1.setName("Worker 1");
		
		Thread worker2=new Thread(j);
		worker2.setName("Worker 2");
		
		worker1.start();
		worker2.start();
		
		
		
		
		
		
	}

}
