package com.usingThreadClass;
class PrintMessage extends Thread
{
	
	String mesg;
	PrintMessage(String mesg)
	{
		this.mesg=mesg;
		
	}
	
	
	
	public void run()
	{
		// Write the business logic for thread in this method
		
		System.out.println(mesg+Thread.currentThread().getName());
	}
	
	
	
}





public class ThreadsDemo {

	public static void main(String[] args) 
	{
		
	// Create an instance object of thread class
		
		PrintMessage p=new PrintMessage("Welcome All");
		PrintMessage p1=new PrintMessage("Welcome All");
		PrintMessage p2=new PrintMessage("Welcome All");
		p.setName("Printer Thread");
		
		System.out.println(p.getName());
		System.out.println(Thread.currentThread());
		
		
		p1.start();
		p2.start();
		
		
		
	}

}
